from Config import Config

config = Config()
config.set_values({'width': 550, 'height': 550,  'level': 'level1', 'tile_size': 50})
